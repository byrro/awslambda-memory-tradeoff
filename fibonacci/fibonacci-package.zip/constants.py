'''Constant values for Fibonacci Lambda'''


DEFAULT_FIBONACCI_N = 20
